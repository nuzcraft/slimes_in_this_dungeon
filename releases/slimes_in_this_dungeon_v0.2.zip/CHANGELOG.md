## Changelog
### 2020.03.01 Day 2!
* 5:00 AM, up early! I was hoping to get some dev time in before the family wakes up, and it worked out!
* I finished a couple sections of the project plan:
* added enemies
* gave them simple ai
* added combat (one hit kills)
* added level exits
* TECHNICALLY it's now a game! It has a start, gameplay with a goal, and an end. There's lots more to do though! The next step is to add the collectible crystals and the gameplay mechanic where they will unlock the stairs.
* 1.25 hrs
* 8:30 PM (ish) I'm back!! I can't remember where we're starting tho 😅
* aight! great progress tonight!! I got it set up so the player can collect crystals and use them to advance to the next level. There are currently 3 crystals to collect then a final floor to escape the dungeon. Since enemy ai is pretty simple and the player can only bump attack, its actually pretty hard to win!
* I'll be uploading a Day 2 build to itch.io today as well.
* 2 hours
* Total Dev Time: 3.25 hours
### 2020.02.29 Day 1 begins!
* 5:30 AM, 7DRL has begun!!
* 7 WHOLE MINUTES OF WORK before I had to stop to help deal with a kid 😑
* I made good progress for only ~45 mins of time spent. I've got a working title screen and the start of something good! I grabbed the spritesheet from Row Jam Brough for now, but that will be replaced with a new one when I get there. So exciting!!
* 45 mins
* 8:30 PM (ish), I got back into this. There were a couple interruptions, and I was watching the Monster Hunter US Championship (which was awesome).
* Despite that, I made good progress. We've got a player that can move around an empty level. The next step is to add some slimes and start buildig out basic combat. I'm also going to upload my first build to itch.io (which will take 10-15 mins)
* 1.5 hrs
* Total Dev Time - 2.25 hrs
### 2020.02.18 Some Smaller Tasks
I started the process of creating tasks for each of the different sections of the project. This should be very helpful on deciding what to work on at each point of the process. Obviously, these will flow and adjust once the coding has started. I also split the README out into a few different files - readme, changelog, design, and project_plan. Hopefully this will help with organization and allow the readme to be a lot smaller.
### 2020.02.13 Stretch Goals
I finished up the required task groups and started looking at what stretch goals would be. The next step is start defining tasks and figuring out how long I think this is gonna take. 
### 2020.02.10 Design Changes
Over the weekend, I was thinking about this and decided that I'm going to move away from the level select idea. I think it adds unnecessary tedium for very little gain. The original idea was that you could define your run by choosing your path, but the reality is that the game isn't long enough for that. Instead, levels will come out randomly and new levels will be able to spawn enemies from previous levels. I also started setting out task groups for the project plan. This is starting to come together!!
### 2020.02.07 Color Specifics
I defined some the the specifics to the different colors I want to use.
### 2020.02.06 Game Flow
Today, I started working on the game flow. Basically, the player will go through a couple different dungeon levels collection crystals. The crystals will grant special abilities. After collecting all 3, they have to escape. There's a level selector that sits between the levels. I also added some Decisions that can be used to help drive design in the direction I'm thinking.
### 2020.02.04 Starting the Design
This will be my first attempt at a 7DRL and I'm terrified. I've tried a couple other game jams in the past (GM48) with little success, mostly due to a lack of time, but also due to a lack of experience. This README will comprise all the normal README garbage, but will also be my design document as I begin planning my week of development. I'm very excited! My idea for a game is _really simple_ and I think thats the best way to go for my first try. I'll be coming up with a pseudo-timeline as well as plan extra features in case things go better than expected (they won't).